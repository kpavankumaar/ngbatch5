var desielEngine = {
    engineType: 'deseil',
    brand: 'fiat',
    details: function (a, b) {
    }
};
console.log(desielEngine);
var electricVehicle = {
    engineType: 'petrol',
    brand: 'ford',
    details: function (b, c) {
    }
};
console.log(electricVehicle);
function run() {
    return 10;
}
console.log(run());
