"use strict";
exports.__esModule = true;
var EngineInfo;
(function (EngineInfo) {
    var Engine = /** @class */ (function () {
        function Engine(engine) {
            this.engine = engine;
            this.engineType = engine;
        }
        return Engine;
    }());
    EngineInfo.Engine = Engine;
})(EngineInfo = exports.EngineInfo || (exports.EngineInfo = {}));
// var engine = new Engine('diesel1200cc');
// console.log(engine);
//EngineInfo.Engine.test();
