export interface TriesDSUpdation{
    ipdateIntoDS(length:number,element:number);number;
}