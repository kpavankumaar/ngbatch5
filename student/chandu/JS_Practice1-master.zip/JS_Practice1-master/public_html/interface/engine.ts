export namespace EngineInfo{
    export class Engine{
        engineType;
    
        constructor(public engine){
            this.engineType = engine;
        }
    
        // constructor(public engine){
    
        // }
    
        // static test(){
        //     console.log("came");
        // }
    }
}



// var engine = new Engine('diesel1200cc');
// console.log(engine);

//EngineInfo.Engine.test();