class ParentDS{
    lengthOfDS:number;
}