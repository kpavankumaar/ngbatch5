export interface TriesDSInsertion{    
    insertIntoDS(length:number,elementToInsert:number):void;
}