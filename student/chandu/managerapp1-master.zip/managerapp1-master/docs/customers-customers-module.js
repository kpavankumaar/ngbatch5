(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["customers-customers-module"],{

/***/ "./src/app/customers/customers-card.component.css":
/*!********************************************************!*\
  !*** ./src/app/customers/customers-card.component.css ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2N1c3RvbWVycy9jdXN0b21lcnMtY2FyZC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/customers/customers-card.component.html":
/*!*********************************************************!*\
  !*** ./src/app/customers/customers-card.component.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\" *ngIf =\"!!userData\">\n  <div class=\"row\" >\n    <div class=\"col-sm-4\" *ngFor=\"let item of userData\" >\n      <div class=\"card\">\n        <div class=\"card-header\">\n          <a [routerLink]=\"['/customers',item.id,'details']\">{{item.firstName | uppercase }} {{item.lastName | uppercase}}</a>\n          <a [routerLink]=\"['/customers',item.id,'edit']\">Edit</a>\n        </div>\n        <div class=\"card-body\">\n          <h5 class=\"card-title\">Special title treatment</h5>\n          <p class=\"card-text\">Gender {{item.gender}}</p>\n          <a href=\"#\" class=\"btn btn-primary\">View Orders</a>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n<button (click) = 'clickEvent()'>click me </button>"

/***/ }),

/***/ "./src/app/customers/customers-card.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/customers/customers-card.component.ts ***!
  \*******************************************************/
/*! exports provided: CustomersCardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomersCardComponent", function() { return CustomersCardComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var CustomersCardComponent = /** @class */ (function () {
    function CustomersCardComponent() {
    }
    CustomersCardComponent.prototype.ngOnInit = function () {
    };
    CustomersCardComponent.prototype.ngOnChanges = function () {
        console.log('customers component detection is find ', this.userData);
    };
    CustomersCardComponent.prototype.clickEvent = function () {
        console.log('click event from card component');
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], CustomersCardComponent.prototype, "userData", void 0);
    CustomersCardComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-customers-card',
            template: __webpack_require__(/*! ./customers-card.component.html */ "./src/app/customers/customers-card.component.html"),
            styles: [__webpack_require__(/*! ./customers-card.component.css */ "./src/app/customers/customers-card.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], CustomersCardComponent);
    return CustomersCardComponent;
}());



/***/ }),

/***/ "./src/app/customers/customers-grid.component.css":
/*!********************************************************!*\
  !*** ./src/app/customers/customers-grid.component.css ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2N1c3RvbWVycy9jdXN0b21lcnMtZ3JpZC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/customers/customers-grid.component.html":
/*!*********************************************************!*\
  !*** ./src/app/customers/customers-grid.component.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p>\n  customers-grid works!\n</p>\n"

/***/ }),

/***/ "./src/app/customers/customers-grid.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/customers/customers-grid.component.ts ***!
  \*******************************************************/
/*! exports provided: CustomersGridComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomersGridComponent", function() { return CustomersGridComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var CustomersGridComponent = /** @class */ (function () {
    function CustomersGridComponent() {
    }
    CustomersGridComponent.prototype.ngOnInit = function () {
    };
    CustomersGridComponent.prototype.ngOnChanges = function () {
        console.log('customer grid component on change detection');
    };
    CustomersGridComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-customers-grid',
            template: __webpack_require__(/*! ./customers-grid.component.html */ "./src/app/customers/customers-grid.component.html"),
            styles: [__webpack_require__(/*! ./customers-grid.component.css */ "./src/app/customers/customers-grid.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], CustomersGridComponent);
    return CustomersGridComponent;
}());



/***/ }),

/***/ "./src/app/customers/customers.component.css":
/*!***************************************************!*\
  !*** ./src/app/customers/customers.component.css ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2N1c3RvbWVycy9jdXN0b21lcnMuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/customers/customers.component.html":
/*!****************************************************!*\
  !*** ./src/app/customers/customers.component.html ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- <app-customers-card></app-customers-card> -->\n\n<nav>\n    <a (click)=\"pageLoad('card')\">\n        cardView\n    </a>\n    <a (click)=\"pageLoad('list')\">\n        listView\n    </a>\n</nav>\n<div *ngIf='cardStatus'>\n    <app-customers-card [userData] = \"data\"></app-customers-card>\n</div>\n<div *ngIf='listStatus'>\n        <app-customers-grid></app-customers-grid>\n</div>\n\n"

/***/ }),

/***/ "./src/app/customers/customers.component.ts":
/*!**************************************************!*\
  !*** ./src/app/customers/customers.component.ts ***!
  \**************************************************/
/*! exports provided: CustomersComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomersComponent", function() { return CustomersComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _core_services_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../core/services/data.service */ "./src/app/core/services/data.service.ts");



var CustomersComponent = /** @class */ (function () {
    function CustomersComponent(dataService) {
        this.dataService = dataService;
    }
    CustomersComponent.prototype.pageLoad = function (choosePage) {
        if (choosePage === 'card') {
            this.cardStatus = true;
            this.listStatus = false;
        }
        else if (choosePage === 'list') {
            this.cardStatus = false;
            this.listStatus = true;
        }
    };
    CustomersComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.dataService.getCustomersData().subscribe(function (res) {
            console.log(res);
            _this.data = res;
        });
    };
    CustomersComponent.prototype.ngOnChanges = function () {
        console.log('customers component on change detection');
    };
    CustomersComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-customers',
            template: __webpack_require__(/*! ./customers.component.html */ "./src/app/customers/customers.component.html"),
            providers: [_core_services_data_service__WEBPACK_IMPORTED_MODULE_2__["DataService"]],
            styles: [__webpack_require__(/*! ./customers.component.css */ "./src/app/customers/customers.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_core_services_data_service__WEBPACK_IMPORTED_MODULE_2__["DataService"]])
    ], CustomersComponent);
    return CustomersComponent;
}());



/***/ }),

/***/ "./src/app/customers/customers.module.ts":
/*!***********************************************!*\
  !*** ./src/app/customers/customers.module.ts ***!
  \***********************************************/
/*! exports provided: CustomersModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomersModule", function() { return CustomersModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _routingmodule__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./routingmodule */ "./src/app/customers/routingmodule.ts");




var CustomersModule = /** @class */ (function () {
    function CustomersModule() {
        console.log('customers module');
        //console.log(dataService.g);
    }
    CustomersModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _routingmodule__WEBPACK_IMPORTED_MODULE_3__["CustomerRoutingModule"]],
            declarations: [_routingmodule__WEBPACK_IMPORTED_MODULE_3__["CustomerRoutingModule"].components],
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], CustomersModule);
    return CustomersModule;
}());



/***/ }),

/***/ "./src/app/customers/routingmodule.ts":
/*!********************************************!*\
  !*** ./src/app/customers/routingmodule.ts ***!
  \********************************************/
/*! exports provided: CustomerRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerRoutingModule", function() { return CustomerRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _customers_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./customers.component */ "./src/app/customers/customers.component.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _customers_card_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./customers-card.component */ "./src/app/customers/customers-card.component.ts");
/* harmony import */ var _customers_grid_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./customers-grid.component */ "./src/app/customers/customers-grid.component.ts");






var customersRoute = [
    { path: '', component: _customers_component__WEBPACK_IMPORTED_MODULE_2__["CustomersComponent"] }
];
var CustomerRoutingModule = /** @class */ (function () {
    function CustomerRoutingModule() {
    }
    CustomerRoutingModule.components = [_customers_component__WEBPACK_IMPORTED_MODULE_2__["CustomersComponent"], _customers_card_component__WEBPACK_IMPORTED_MODULE_4__["CustomersCardComponent"], _customers_grid_component__WEBPACK_IMPORTED_MODULE_5__["CustomersGridComponent"]];
    CustomerRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forChild(customersRoute)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        })
    ], CustomerRoutingModule);
    return CustomerRoutingModule;
}());



/***/ })

}]);
//# sourceMappingURL=customers-customers-module.js.map